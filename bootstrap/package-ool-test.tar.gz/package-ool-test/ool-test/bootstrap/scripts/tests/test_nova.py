#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
import os
sys.path.append(os.path.abspath(os.path.dirname(__file__)) + "/../")
import api.nova_client as nova


nova_client = nova.get_client()
aggregate = nova_client.aggregates.list()
print aggregate
columns = ['Id', 'Name', 'Availability Zone']

objs = aggregate
keys = ['availability_zone']
def get_attr(obj, keys):
	ret = []
	for o in objs:
		for key in keys:
			data = getattr(o, key, '')
			ret.append(data)
	return ret
