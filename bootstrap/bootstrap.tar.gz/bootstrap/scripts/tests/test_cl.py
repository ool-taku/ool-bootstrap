#!/usr/bin/env python
# -*- coding: utf-8 -*-
from novaclient.v1_1 import client as nc 
from neutronclient.v2_0 import client as nec

USER="admin"
PASS="admin"
TENANT="admin"
AUTH_URL="http://localhost:5000/v2.0/"

#nt = "" 
#nt = nc.Client(USER, PASS, TENANT, AUTH_URL)
nect = nec.Client( username=USER, password=PASS, tenant_name=TENANT, auth_url=AUTH_URL)
print nec
for subnet in nect.list_networks()["networks"]:
	for sub in subnet["subnets"]:
		print sub + ":" + subnet["id"]

#print nect.list_subnets()
#ret=nt.flavors.list()
#print ret[0].name
#aggregate = nt.aggregates.create("ag-", "dd")
#print aggregate

#keys=nt.keypairs.create("testkey3")
#print keys.private_key
