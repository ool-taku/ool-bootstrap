#!/usr/bin/env python
# -*- coding: utf-8 -*-

import sys
import os
from string import Template
sys.path.append(os.path.abspath(os.path.dirname(__file__)) + "/../")
import db.db_manager as db_manager 
import db.db_wrapper as db_wrapper
argvs = sys.argv
import log

db_wrapper.update_scenario_status("ed69af64-4821-11e3-82b3-5254000a40f1",'1')
ret=db_manager.select(argvs[1])

for row in ret:
	print row

#db_manager.execute(argvs[1])
