function redirect_page(url){
	location.href = url;
}
