#!/usr/bin/env python
# coding: utf-8

import os
import sys
import cgi
import cgitb; cgitb.enable()
import time

time.sleep(5)

print "Content-type: text/html\n"
#print "<html><body>"
print "Active"
#print "</body></html>"
