#!/usr/bin/env python
# coding: utf-8

import os
import sys
import cgi
import cgitb; cgitb.enable()
from string import Template
sys.path.append(os.getcwd() + "/../scripts")
#import common.scenario as scenario
from common.scenario import Scenario
import urllib

_scenario = None

def param_list(scenario_param):
        ret=""
	global _scenario
#	for section_key in scenario.get_sections():
	for section_key in _scenario.get_sections():
		if not scenario_param.has_key(section_key):
			continue
		for key in scenario_param[section_key].keys():
			ret += """<tr><td>%s</td><td><input type="text" style="width:90%%" name="%s" value="%s">""" % (key, key, scenario_param[section_key][key])
			ret += """<input type="hidden" name="%s" value="%s"></input></td></tr>""" % (section_key, key)
	return ret

def show_scenario():
	global _scenario
#	scenario_param = scenario.read_scenario()
	scenario_param = _scenario.read_scenario()
	with open(os.getcwd() + '/template/edit_scenario.tmpl') as f:
        	data=f.read()
		tmpl=Template(unicode(data, 'utf-8', 'ignore'))
		body=tmpl.substitute({'scenario':param_list(scenario_param),'select_scenario':scenario_name,'scenario_name':scenario_name})
		print "Content-type: text/html\n"
		print body.encode('utf-8')

def save_scenario():
	global _scenario
#	scenario_param = scenario.read_scenario()
	scenario_param = _scenario.read_scenario()
	scenarios = {}
#	for section in scenario.get_sections():
	for section in _scenario.get_sections():
		section_map = {}
		for key in form.getlist(section):
			section_map[key] = form[key].value
		scenarios[section] = section_map
#	scenario.save_scenario(scenarios)
	_scenario.save_scenario(scenarios)
	show_scenario()

if os.environ['REQUEST_METHOD'] != "POST":
        log.error("Not found POST method.")
        sys.exit(1)

form = cgi.FieldStorage()
if not form.has_key("scenario"):
        log.error("Not found Parametor scenario.")
        sys.exit(1)

script_path = os.path.abspath(os.path.dirname(__file__))

scenario_name = form['scenario'].value
#scenario.set_scenario(script_path + "/../../scenario/" + scenario_name)
_scenario = Scenario(script_path + "/../../scenario/" + scenario_name)

if not form.has_key("is_save"):
	show_scenario()
else:
	save_scenario()

