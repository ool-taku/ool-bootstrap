#!/usr/bin/env python 
# coding: utf-8

import os
import sys
import uuid
import cgi
import pwd
import cgitb; cgitb.enable()
import threading
import subprocess
from string import Template
sys.path.append(os.getcwd() + "/../scripts")
import common.credentials as credentials 
import log

#print "Content-type: text/html\n"
#print "Location: index.py\n\n"
#print """<META HTTP-EQUIV="Refresh" CONTENT="5"; URL="index.py" />"""


def exec_build(scenario, scid):
	script_path = os.path.abspath(os.path.dirname(__file__))
	log_path = "%s/../../log/%s" % (script_path, scid)
	exe_path = "%s/../../scripts/bootstrap.py" % script_path
	try:
	        f=open(log_path, "w")
	except IOError as e:
	        log.error("can not open :" + log_path)
	        log.error( str(type(e)) + str(e.args) + e.message)
	        sys.exit(1)

	try:
	        log.info("Start to Build scenario : '%s',  uuid : '%s'" % (scenario, scid))
	        subprocess.Popen(["sudo","/usr/bin/python", exe_path, scid, scenario, "credentials"], stdout=f, stderr=f)
	except OSError as e:
	        log.error( str(type(e)) + str(e.args) + str(e.message) )
	        sys.exit(1)


if os.environ['REQUEST_METHOD'] != "POST":
	log.error("Not found POST method.")
	sys.exit(1)

form = cgi.FieldStorage()
if not form.has_key("scenario"):
	log.error("Not found Parametor scenario.")
	sys.exit(1)

exec_build(form['scenario'].value, str(uuid.uuid1()))

with open(os.getcwd() + '/template/redirect.tmpl') as f:
	data=f.read()
	tmpl=Template(unicode(data, 'utf-8', 'ignore'))
	body=tmpl.substitute({'url':'index.py'})
	print "Content-type: text/html\n"
	print body.encode('utf-8')
