#!/usr/bin/env python
# coding: utf-8

import cgi
import cgitb; cgitb.enable()
import sys
import threading
import shlex
import time
import subprocess
import os
from string import Template
sys.path.append(os.getcwd() + "/../scripts")
import log

def exec_release(scid, lbaas):
	script_path = os.path.abspath(os.path.dirname(__file__))
	command = "sudo /usr/bin/python " + script_path + "/../../scripts/release.py " + scid
	if lbaas:
		command += " " + lbaas
	try:
        	log.info("Start to delete id : " + scid)
        	subprocess.Popen(shlex.split(command))
	except OSError as e:
        	log.error( str(type(e)) + str(e.args) + e.message)
        	sys.exit(1)

form = cgi.FieldStorage()
if not form.has_key('scid'):
        log.error("Not found Parametor scenario-id.")
        sys.exit(1)

#options = []
#for k, v in form.items():
#	if k == 'scid':
#		continue
#	if v == 'True':
#		options.append(k)
#log.debug("delete options : %s" % str(options))

lbaas = ''
if form.has_key('lbaas') and form['lbaas'].value == 'True':
	lbaas = 'lbaas'

exec_release(form['scid'].value, lbaas)

with open(os.getcwd() + '/template/redirect.tmpl') as f:
	data=f.read()
	tmpl=Template(unicode(data, 'utf-8', 'ignore'))
	body=tmpl.substitute({'url':'index.py'})
	print "Content-type: text/html\n"
	print body.encode('utf-8')
	log.debug("redirect.tmpl print.")
