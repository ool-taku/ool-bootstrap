#!/bin/bash

ls -l /
